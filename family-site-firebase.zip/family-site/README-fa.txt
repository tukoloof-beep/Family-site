راهنمای گذاشتن «فمیلی سایت» روی گوگل (Firebase Hosting) — رایگان

۱) به console.firebase.google.com بروید، با حساب گوگل وارد شوید و «Add project» بزنید. (Google Analytics را خاموش کنید.)

۲) داخل پروژه: Build ← Firestore Database ← Create database ← یک منطقه انتخاب کنید ← «Production mode».

۳) آیکن </> (Web app) را بزنید و یک اسم بدهید. اطلاعات firebaseConfig را نشان می‌دهد.
   مقدارهای apiKey و projectId و appId را در فایل public/firebase-config.js جای PASTE بگذارید
   (در authDomain هم PASTE_PROJECT_ID را با projectId عوض کنید).

۴) Node.js را از nodejs.org نصب کنید. ترمینال را در همین پوشه باز کنید (VS Code: Terminal ← New Terminal) و بزنید:
     npm install -g firebase-tools
     firebase login
     firebase use --add        (پروژه‌ی خودتان را انتخاب کنید)
     firebase deploy

۵) آخرش آدرس سایت را می‌دهد، مثل: https://اسم-پروژه.web.app
   این لینک را برای خانواده بفرستید. رمز ورود: 1406

نکته‌ها:
- عکس‌ها در Firestore ذخیره می‌شوند و برای همه مشترک‌اند (نیازی به کارت بانکی نیست).
- رمز 1406 فقط یک قفل ساده است و داخل کد صفحه دیده می‌شود. هر کس آدرس سایت را داشته باشد می‌تواند عکس ببیند و اضافه کند.
- اگر فایل firebase-config.js را پر نکنید، سایت کار می‌کند ولی عکس‌ها فقط روی همان دستگاه می‌مانند.
