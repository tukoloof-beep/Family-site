// اطلاعات پروژه‌ی Firebase خودتان را اینجا بگذارید (راهنما در README-fa.txt)
export const firebaseConfig = {
  apiKey: "PASTE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  appId: "PASTE_APP_ID"
};
