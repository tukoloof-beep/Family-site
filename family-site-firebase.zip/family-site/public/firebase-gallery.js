import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getFirestore, collection, addDoc, deleteDoc, doc, onSnapshot } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const toDataURL = b => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(b); });

if (firebaseConfig && firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith("PASTE")) {
  const db = getFirestore(initializeApp(firebaseConfig));
  window.fb = {
    watch(cb, err) {
      return onSnapshot(collection(db, "photos"), snap => {
        cb(snap.docs.map(d => { const v = d.data(); return { docId: d.id, ts: v.ts || 0, src: v.data }; })
          .sort((x, y) => x.ts - y.ts));
      }, err);
    },
    async add(blob) {
      const data = await toDataURL(blob);
      if (data.length > 900000) throw new Error("too big");
      await addDoc(collection(db, "photos"), { data, ts: Date.now() });
    },
    async remove(it) { await deleteDoc(doc(db, "photos", it.docId)); }
  };
  window.dispatchEvent(new Event("fbready"));
}
